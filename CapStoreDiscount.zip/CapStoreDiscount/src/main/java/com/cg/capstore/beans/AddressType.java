package com.cg.capstore.beans;

public enum AddressType 
{
	HOME,WORK
}
