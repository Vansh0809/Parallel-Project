package com.cg.capstore.beans;

public enum MerchantType
{
	NORMAL,THIRD_PARTY;
}
